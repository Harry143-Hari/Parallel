package com.capgemini.dao.services;

import com.capgemini.dao.bean.*;
import com.capgemini.dao.bean.Account;
import com.capgemini.dao.exceptions.AccountMismatchException;
import com.capgemini.dao.exceptions.AccountNotFoundException;
import com.capgemini.dao.exceptions.InsufficientBalanceException;

public interface BankingService {

	void  createAccount(Account account);

	void deposit(double amount, Integer accno) throws AccountNotFoundException;

	void withDraw(double amount, Integer accno) throws AccountNotFoundException, InsufficientBalanceException;

	void fundTransfer(Integer accno1, Integer accno2) throws AccountNotFoundException, InsufficientBalanceException, AccountMismatchException;

	//void showBalance(Integer accno) throws AccountNotFoundException;

	//void printTransactions(Integer accNo) throws AccountNotFoundException;
	
}
