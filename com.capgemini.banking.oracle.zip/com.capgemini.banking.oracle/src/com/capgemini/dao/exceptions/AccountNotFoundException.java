package com.capgemini.dao.exceptions;

import java.util.Scanner;

public class AccountNotFoundException extends Exception{

	public AccountNotFoundException(Integer accno, String string) {
		super(accno+" "+string);
		Scanner sc=new Scanner(System.in);
		System.err.println(accno+" "+string);
		sc.nextLine();
		
	}

}
